All-in-Clean demo website
-------------------------
Files in this package:
  - index.html
  - style.css
  - placeholder-window.jpg

Usage:
  1. Unzip and check index.html in a browser to preview locally.
  2. Upload the contents of the folder to Netlify (drag & drop), Vercel, or GitHub Pages.
  3. Replace the mailto: action in the contact form with your email or a form processor (Netlify Forms or a backend endpoint).
  4. Replace placeholder-window.jpg with real photos where needed.

Contact info embedded (from public directories):
  - Telefoon: +31 6 55 76 26 24
  - Adres: Ambachtsweg 39h, 2641 KT Pijnacker

Note: This is a demo package. Forms are demo (mailto) and show an alert. Replace as required.